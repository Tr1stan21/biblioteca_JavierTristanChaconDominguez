package tareaGit;

public class Tarea1GIT {

	public static void main(String[] args) {
		int valor1 = 3;
		int valor2 = 7;
		int resultado = valor1 + valor2;
	}

}
